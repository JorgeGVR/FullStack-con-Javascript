
export interface Iempleado {
  id?: number;
  cedula: string;
  nombre: string;
  idCargo: string;
  idDepartamento: string;
  sueldo: number;
  estado: number;
  created_at: Date;
}
